import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
	 readonly APIUrl = "http://localhost:5000/api";

  constructor(private http: HttpClient) { }
  
  getProductList(): Observable<any[]> {
    return this.http.get<any>(this.APIUrl + '/getProductList');
  }
  
  getInvoiceList(): Observable<any[]> {
    return this.http.get<any>(this.APIUrl + '/getInvoiceList');
  }
  
  getPrice(val: any): Observable<any[]> {
    return this.http.get<any>(this.APIUrl + '/getPrice/' + val);
  }
  
  getProductname(val: any): Observable<any[]> {
    return this.http.get<any>(this.APIUrl + '/getProductname/' + val);
  }
  
   InsertRecord(val: any) {
    return this.http.post(this.APIUrl + '/InsertRecord', val);
  }
  
  InsertTransPro(val: any) {
    return this.http.post(this.APIUrl + '/InsertTransPro', val);
  }
  
  getTrProducts(val: any): Observable<any[]> {
    return this.http.get<any>(this.APIUrl + '/getTrProducts/' + val);
  }
  
}
