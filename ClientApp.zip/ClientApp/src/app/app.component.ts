import { Component, OnInit } from '@angular/core';
import { SharedService } from './shared.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'angularn';
  HighlightRow: Number = 0;
  isLoggedIn2:boolean  = false;



  constructor(private service: SharedService) {
	
   
	
  }
  ngOnInit(): void {
   
  }
  
 login(){
this.isLoggedIn2 = true;
 }	 
  logout(){
	 this.isLoggedIn2 = false; 
  }
 
  
}
