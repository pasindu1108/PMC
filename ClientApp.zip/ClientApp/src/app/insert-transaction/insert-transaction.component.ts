import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import Swal from 'sweetalert2';
import pdfMake from "pdfmake/build/pdfmake";  
import pdfFonts from "pdfmake/build/vfs_fonts"; 
pdfMake.vfs = pdfFonts.pdfMake.vfs; 

@Component({
  selector: 'sb-insert-transaction',
  templateUrl: './insert-transaction.component.html',
  styleUrls: ['./insert-transaction.component.scss']
})
export class InsertTransactionComponent implements OnInit {

  constructor(private service: SharedService) { }

 ProList: any = [];
 Products: any = [];
 ID: Number;
 Discount: any;
 Qty: any;
 Item: any;
 Name: String;
 Date: String;
 Price: Number;
 UnitPrice: any;
 Total: Number;
 T: Number = 0;
 ProductName: any;
 Bill: Number;
 filename:String;
 filepath: string;

  ngOnInit(): void {
	  
	  this.getProductList();
  }


closeClick(){
	this.Qty = 0;
	this.Discount = 0;
	this.ID = 0;
}

getProductList(){
    this.service.getProductList().subscribe(data => {
      this.ProList = data;
	  console.log(data);
    });
}

AddProducts(){
	
this.service.getPrice(this.ID).subscribe(data => {
	  console.log(data);
	  this.UnitPrice = data;
	  console.log(this.UnitPrice);
	this.Price = (this.UnitPrice * this.Qty) - this.Discount;
	this.Item = {ID: this.ID,Discount: this.Discount,Qty: this.Qty,Price: this.Price};
	this.Products.push(this.Item);
	
});

}

clear(){
	this.Name='';
	this.Date='';
	this.Products=[];
}


returnname(ID){
	this.service.getProductname(ID).subscribe(data => {
	 
	this.ProductName = data;
});
return this.ProductName;
}

generate(){
	this.Bill = parseInt((Math.random() * 1000).toFixed(0));
	if(this.Name == undefined){
		
		Swal.fire('','Please Fill Mandotary Fields !','warning');
		
	} else {
		if(this.Products.length < 1) {
		Swal.fire('','Please Add Products !','warning');
		} else { 
		
		let docDefinition = {  
				content: [  
			  {  
				text: 'MC Solutions',  
				fontSize: 16,  
				alignment: 'center',  
				color: '#047886'  
			  },  
			  {  
				text: 'INVOICE',  
				fontSize: 20,  
				bold: true,  
				alignment: 'center',  
				decoration: 'underline',  
				color: 'black'  
			  },
            {  
            text: 'Customer Details',  
            style: 'sectionHeader'  
            },
            {columns: [  
                [  
                    {  
                        text: this.Name,  
                        bold: true  
                    },   
                ],  
                [  
                    {  
                        text: `Date: ${new Date().toLocaleString()}`,  
                        alignment: 'right'  
                    },
                    {  
                        text: "Bill No - "+this.Bill,  
                        alignment: 'right'  
                    }					
                ]  
            ]},
			{  
				text: 'Order Details',  
				style: 'sectionHeader'  
			},  
			{  
				table: {  
					headerRows: 1,  
					widths: ['*', 'auto', 'auto', 'auto'],  
					body: [  
						['Product ID', 'Discount', 'Quantity', 'Price'],
				        ...this.Products.map(p => ([p.ID, p.Discount, p.Qty, p.Price]) ),
						[{ text: 'Total Amount', colSpan: 3 }, {}, {}, this.Products.reduce((sum, p) => sum + (p.Price), 0).toFixed(2)]
						
						 
					]  
				}  
			},
			{
			    ul: [  
              'Order can be return in max 7 days.',  
              'Warrenty of the product will be subject to the manufacturer terms and conditions.',  
              'This is system generated invoice.',  
            ]  
             } 
            ]			  
        };  
       // pdfMake.createPdf(docDefinition).open();
        this.filename = 'Bill'+this.Bill+'.pdf';	   
		pdfMake.createPdf(docDefinition).open();
		
	
	
	var val = {
		Name: this.Name,
		Bill: this.Bill,
		File: this.filename	
	};
	
       this.service.InsertRecord(val).subscribe(res => {
      console.log(res); 
	   Swal.fire('', 'Successfully Inserted!', 'success'); 
	 });
	 
	    console.log(this.Products);
	 for (var i = 0; i < this.Products.length; i += 1) {
		var val2 = {
	    ProductId:this.Products[i].ID,
		Qty:this.Products[i].Qty,
		BillNo:this.Bill};
		console.log(val2);
		this.service.InsertTransPro(val2).subscribe(res => {
			
			});
	 }
	   
	   
	 //  this.Name='';
	//this.Date='';
	//this.Products=[];

		
		
		}
	}
}	
		 

}


