import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { SharedService } from './shared.service';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InsertTransactionComponent } from './insert-transaction/insert-transaction.component';
import { InvoicesComponent } from './invoices/invoices.component';
import {NgxPaginationModule} from 'ngx-pagination';







@NgModule({
  declarations: [
    AppComponent,
    InsertTransactionComponent,
    InvoicesComponent
  ,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
	NgxPaginationModule,
    
  ],
  providers: [SharedService],
  bootstrap: [AppComponent]
})
export class AppModule { }
