import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import Swal from 'sweetalert2';
import pdfMake from "pdfmake/build/pdfmake";  
import pdfFonts from "pdfmake/build/vfs_fonts"; 
pdfMake.vfs = pdfFonts.pdfMake.vfs; 

@Component({
  selector: 'app-invoices',
  templateUrl: './invoices.component.html',
  styleUrls: ['./invoices.component.css']
})
export class InvoicesComponent implements OnInit {

 constructor(private service: SharedService) { }
 
  InvoiceList: any = [];
   p: number = 1;
   filter: any = [];
   key: string = 'id';
  reverse: boolean = false;
  ProListWithoutFilter: any = [];
  Transactions:any = [];
  CusName: any;
  DateT: any;

  ngOnInit(): void {
	  this.getInvoiceList();
  }



getInvoiceList(){
    this.service.getInvoiceList().subscribe(data => {
      this.InvoiceList = data;
	  this.ProListWithoutFilter = data;
	  console.log(data);
    });
}

closeClick(){
	
}

FilterFn(){
	 var filter = this.filter;
    this.InvoiceList = this.ProListWithoutFilter.filter(function (el) {
      return el.Bill.toString().toLowerCase().includes(
        filter.toString().trim().toLowerCase()
      )
    });
}

Click(dataItem){
	  console.log(dataItem.File)
	  var pdf = dataItem.File;
	  this.CusName = dataItem.Name;
	  this.DateT = dataItem.Date;

this.service.getTrProducts(dataItem.Bill).subscribe(data => {
      this.Transactions = data;
	  console.log(data);
    });
	  
 }

}
