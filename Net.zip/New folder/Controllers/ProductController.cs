﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MCSolutions.Models;
using System.IO;
using Microsoft.AspNetCore.Hosting;

namespace MCSolutions.Controllers
{
    [Route("api")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _env;

        public ProductController(IConfiguration configuration, IWebHostEnvironment env)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("getProductList")]
        public JsonResult getProductList()
        {
            string query = "exec getProductList";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DevConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }
		
		
		[HttpGet, ActionName("getPrice")]
        [Route("getPrice/{ID}")]
        public JsonResult getPrice(int ID)
        {

            
            string StoredProc2 = "exec getPrice " +
                    "@ID = '" + ID + "'";
			
			int price;
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DevConnection");
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(StoredProc2, myCon))
                {
                    price = (int)myCommand.ExecuteScalar();
					myCon.Close();
                }
            }
            return new JsonResult(price);
        }
		
		
		[HttpGet, ActionName("getProductname")]
        [Route("getProductname/{ID}")]
        public JsonResult getProductname(int ID)
        {

            
            string StoredProc2 = "exec getProductname " +
                    "@ID = '" + ID + "'";
			
			string name;
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DevConnection");
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(StoredProc2, myCon))
                {
                   name = (string)myCommand.ExecuteScalar();
					myCon.Close();
                }
            }
            return new JsonResult(name);
        }
		
		
		
		[HttpGet, ActionName("getTrProducts")]
        [Route("getTrProducts/{ID}")]
        public JsonResult getTrProducts(string ID)
        {

            
            string StoredProc2 = "exec getTrProducts " +
                    "@ID = '" + ID + "'";
			
		
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DevConnection");
			SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(StoredProc2, myCon))
                {
                   myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }
		
		
		[HttpPost, ActionName("InsertRecord")]
        [Route("InsertRecord")]
        public JsonResult InsertRecord(Transactions Trn)
        {

            string StoredProc2 = "exec InsertRecord " +
                    "@Name = '" + Trn.Name + "'," +
                    "@Bill = '" + Trn.Bill + "'," +
                    "@File = '" + Trn.File + "'";
					
				

            Boolean permission ;
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DevConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(StoredProc2, myCon))
                {
                    permission = (bool)myCommand.ExecuteScalar();
                    myCon.Close();
                }
            }



            return new JsonResult("Success");
        }
		
		
		
		[HttpPost, ActionName("InsertTransPro")]
        [Route("InsertTransPro")]
        public JsonResult InsertTransPro(ProductsTrans Tr)
        {

            string StoredProc2 = "exec InsertTransPro " +
                    "@ProductID = '" + Tr.ProductId + "'," +
                    "@Qty = '" + Tr.Qty + "'," +
                    "@BillNo = '" + Tr.BillNo + "'";
					
				

            Boolean permission ;
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DevConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(StoredProc2, myCon))
                {
                    permission = (bool)myCommand.ExecuteScalar();
                    myCon.Close();
                }
            }



            return new JsonResult("Success");
        }
		
		
		
        [HttpGet]
        [Route("getInvoiceList")]
        public JsonResult getInvoiceList()
        {
            string query = "exec getInvoiceList";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DevConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }

      

    }
}