﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MCSolutions.Models
{
    public class ProductsTrans 
    {
        public string ProductId { get; set; }
        public int Qty { get; set; }
        public string BillNo { get; set; }
    }
}